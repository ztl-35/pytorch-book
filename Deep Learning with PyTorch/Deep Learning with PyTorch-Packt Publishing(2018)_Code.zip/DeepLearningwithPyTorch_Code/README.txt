Chapter 1 and 9 does not have code.
Chapter 2 to 8 contains code.
